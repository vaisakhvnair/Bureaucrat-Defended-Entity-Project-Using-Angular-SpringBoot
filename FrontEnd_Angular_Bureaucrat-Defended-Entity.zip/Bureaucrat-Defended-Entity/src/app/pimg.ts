export class Pimg {
    pid:string;
    photoloc:string;
    lphotoloc:string
    rphotoloc:string
    bphotoloc:string
    constructor( pid:string,photoloc:string,lphotoloc:string,rphotoloc:string,bphotoloc:string) {
        this.pid=pid;
        this.photoloc=photoloc;
        this.lphotoloc=lphotoloc;
        this.rphotoloc=rphotoloc;
        this.bphotoloc=bphotoloc;
    }
}
