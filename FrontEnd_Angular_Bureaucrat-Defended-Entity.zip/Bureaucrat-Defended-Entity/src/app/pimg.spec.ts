import { Pimg } from './pimg';

describe('Pimg', () => {
  it('should create an instance', () => {
    expect(new Pimg()).toBeTruthy();
  });
});
