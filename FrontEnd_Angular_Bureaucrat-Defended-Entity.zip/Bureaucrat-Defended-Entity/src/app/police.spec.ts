import { Police } from './police';

describe('Police', () => {
  it('should create an instance', () => {
    expect(new Police()).toBeTruthy();
  });
});
