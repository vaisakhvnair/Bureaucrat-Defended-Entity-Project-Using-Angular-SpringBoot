import { FIR } from './fir';

describe('FIR', () => {
  it('should create an instance', () => {
    expect(new FIR()).toBeTruthy();
  });
});
