import { PayRoll } from './pay-roll';

describe('PayRoll', () => {
  it('should create an instance', () => {
    expect(new PayRoll()).toBeTruthy();
  });
});
