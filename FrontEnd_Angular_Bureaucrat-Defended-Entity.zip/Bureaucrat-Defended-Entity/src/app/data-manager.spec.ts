import { DataManager } from './data-manager';

describe('DataManager', () => {
  it('should create an instance', () => {
    expect(new DataManager()).toBeTruthy();
  });
});
