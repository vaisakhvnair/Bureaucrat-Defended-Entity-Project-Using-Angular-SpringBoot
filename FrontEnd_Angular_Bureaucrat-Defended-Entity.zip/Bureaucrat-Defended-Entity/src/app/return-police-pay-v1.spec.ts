import { ReturnPolicePayV1 } from './return-police-pay-v1';

describe('ReturnPolicePayV1', () => {
  it('should create an instance', () => {
    expect(new ReturnPolicePayV1()).toBeTruthy();
  });
});
