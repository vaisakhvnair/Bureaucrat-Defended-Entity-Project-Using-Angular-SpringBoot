import { ReturnDataManagerPayv0 } from './return-data-manager-payv0';

describe('ReturnDataManagerPayv0', () => {
  it('should create an instance', () => {
    expect(new ReturnDataManagerPayv0()).toBeTruthy();
  });
});
