import { ReturnPolicePayv0 } from './return-police-payv0';

describe('ReturnPolicePayv0', () => {
  it('should create an instance', () => {
    expect(new ReturnPolicePayv0()).toBeTruthy();
  });
});
