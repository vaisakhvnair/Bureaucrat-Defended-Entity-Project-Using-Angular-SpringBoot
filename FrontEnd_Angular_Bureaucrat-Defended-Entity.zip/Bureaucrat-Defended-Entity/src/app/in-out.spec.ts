import { InOut } from './in-out';

describe('InOut', () => {
  it('should create an instance', () => {
    expect(new InOut()).toBeTruthy();
  });
});
