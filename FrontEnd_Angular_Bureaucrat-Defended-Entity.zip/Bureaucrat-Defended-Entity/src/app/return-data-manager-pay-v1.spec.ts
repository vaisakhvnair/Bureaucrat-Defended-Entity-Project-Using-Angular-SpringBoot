import { ReturnDataManagerPayV1 } from './return-data-manager-pay-v1';

describe('ReturnDataManagerPayV1', () => {
  it('should create an instance', () => {
    expect(new ReturnDataManagerPayV1()).toBeTruthy();
  });
});
