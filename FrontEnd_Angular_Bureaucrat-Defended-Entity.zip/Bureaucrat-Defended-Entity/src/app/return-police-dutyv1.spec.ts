import { ReturnPoliceDutyv1 } from './return-police-dutyv1';

describe('ReturnPoliceDutyv1', () => {
  it('should create an instance', () => {
    expect(new ReturnPoliceDutyv1()).toBeTruthy();
  });
});
