import { DutyRegister } from './duty-register';

describe('DutyRegister', () => {
  it('should create an instance', () => {
    expect(new DutyRegister()).toBeTruthy();
  });
});
