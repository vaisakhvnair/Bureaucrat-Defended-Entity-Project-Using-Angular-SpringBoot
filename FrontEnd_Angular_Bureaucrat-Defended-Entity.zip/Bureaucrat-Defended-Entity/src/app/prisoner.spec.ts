import { Prisoner } from './prisoner';

describe('Prisoner', () => {
  it('should create an instance', () => {
    expect(new Prisoner()).toBeTruthy();
  });
});
