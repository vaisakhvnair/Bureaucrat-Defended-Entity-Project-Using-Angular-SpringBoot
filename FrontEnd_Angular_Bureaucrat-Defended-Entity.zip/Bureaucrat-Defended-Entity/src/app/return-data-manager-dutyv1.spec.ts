import { ReturnDataManagerDutyv1 } from './return-data-manager-dutyv1';

describe('ReturnDataManagerDutyv1', () => {
  it('should create an instance', () => {
    expect(new ReturnDataManagerDutyv1()).toBeTruthy();
  });
});
