package com.ust.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.ust.Do.DutyRegister;
import com.ust.Do.ReturnPoliceDutyVo;
import com.ust.model.DataManager;
import com.ust.repo.DataManagerRepository;
import com.ust.vo.PayRoll;
import com.ust.vo.ReturnPolicePayV1;
import com.ust.vo.ReturnPolicePayVo;

@Service
public class DataManagerServiceImpl implements IDataManagerService{
	
	
	@Autowired
	RestTemplate rest;
	
	@Autowired
	private DataManagerRepository prepo;

	@Override
	public String saveDataManager(DataManager p) {
		return prepo.save(p).getUserName();
	}

	@Override
	public List<DataManager> getAllDataManager() {
		return prepo.findAll();
	}

	@Override
	public Optional<DataManager> getOneDataManager(String un) {
		return prepo.findById(un);
	}

	@Override
	public boolean isExist(String name) {
		return prepo.existsById(name); 
	}

	@Override
	public void deleteDataManager(String name) {
		prepo.deleteById(name);
	}
	@Override
	public ReturnPolicePayVo getPolicePayDetails(String id) {

		Optional<DataManager> e=getOneDataManager(id);
		String us=e.get().getUserName();
		String url="http://localhost:9006/Pay-roll/rest/pay/one/"+us;
		PayRoll pr=rest.getForObject(url, PayRoll.class);
		ReturnPolicePayVo re = new ReturnPolicePayVo();
		re.setPolice(e.get());
		re.setPayroll(pr);
		return re;
	}

	@Override
	public List<Object> FetchAll() {
		List<DataManager>p=getAllDataManager();
		String url="http://localhost:9006/Pay-roll/rest/pay/all";
		ResponseEntity<PayRoll[]> response = rest.getForEntity(url,PayRoll[].class);
		PayRoll[] pr = response.getBody();
		List<Object> lo= new ArrayList<Object>();
		lo.add(p);
		lo.add(pr);
		return  lo;
	}

	@Override
	public ReturnPolicePayV1 All() {
		List<DataManager>p=getAllDataManager();
		String url="http://localhost:9006/Pay-roll/rest/pay/all";
		ResponseEntity<PayRoll[]> pr=rest.getForEntity(url, PayRoll[].class);
		PayRoll[] pay = pr.getBody();
		ReturnPolicePayV1 re = new ReturnPolicePayV1();
		re.setPol(p);
		re.setProll(pay);
		return re;
	}
	@Override
	public ReturnPoliceDutyVo getPoliceDutyDetails(String id) {
		Optional<DataManager> e=getOneDataManager(id);
		String us=e.get().getUserName();
		String url="http://localhost:9007/Duty-Reg/rest/duty/one/"+us;
		DutyRegister pr=rest.getForObject(url, DutyRegister.class);
		ReturnPoliceDutyVo re = new ReturnPoliceDutyVo();
		re.setPolice(e.get());
		re.setDuty(pr);
		return re;
	}
}
