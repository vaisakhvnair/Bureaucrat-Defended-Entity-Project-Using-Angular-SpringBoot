package com.ust.service;

import java.util.List;
import java.util.Optional;

import com.ust.Do.ReturnPoliceDutyVo;
import com.ust.model.DataManager;
import com.ust.vo.ReturnPolicePayV1;
import com.ust.vo.ReturnPolicePayVo;

public interface IDataManagerService {
	
	public String saveDataManager(DataManager s);
	public List<DataManager> getAllDataManager();
	public Optional<DataManager> getOneDataManager(String nm);
	public boolean isExist(String name);
	public void deleteDataManager(String name);
	public ReturnPolicePayVo getPolicePayDetails(String id);
	public List<Object>FetchAll();
	public ReturnPolicePayV1 All();
	public ReturnPoliceDutyVo getPoliceDutyDetails(String id);

}
