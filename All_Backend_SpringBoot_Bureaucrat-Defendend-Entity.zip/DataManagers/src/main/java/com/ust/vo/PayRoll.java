package com.ust.vo;

import lombok.Data;

@Data
public class PayRoll {

	
	private String userName;
	private String pid;
	private String name;
	private String regularSalary;
	private String partTimeSalary;
	private String annualSalary;
	
	

}
