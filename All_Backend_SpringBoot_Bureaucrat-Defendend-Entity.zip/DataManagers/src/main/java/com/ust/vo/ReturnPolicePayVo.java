package com.ust.vo;

import com.ust.model.DataManager;

import lombok.Data;
@Data
public class ReturnPolicePayVo {
	
	public DataManager police;
	public PayRoll payroll;
	
	

}
