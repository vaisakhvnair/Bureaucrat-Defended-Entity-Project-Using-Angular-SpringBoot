package com.ust.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="DataManager_tab")
public class DataManager {

	@Id
	private String userName;
	private String password;
	private String id;
	private String name;
	private String designation;
	private String hiredate;
	private String email;
	private String address;

	

}
