package com.ust.Do;

import java.util.List;

import com.ust.model.DataManager;

import lombok.Data;
@Data
public class ReturnPoliceDutyV1 {
	
	public List<DataManager> pol;
	public DutyRegister[] proll;
	
	

}
