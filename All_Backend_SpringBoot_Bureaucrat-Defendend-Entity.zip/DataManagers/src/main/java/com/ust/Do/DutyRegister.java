package com.ust.Do;

import lombok.Data;

@Data
public class DutyRegister {

	
	private String userName;
	private String date;
	private String timeOnDuty;
	private String name;
	private String dutyPoint;
	private String timeOffDuty;
	
	

}
