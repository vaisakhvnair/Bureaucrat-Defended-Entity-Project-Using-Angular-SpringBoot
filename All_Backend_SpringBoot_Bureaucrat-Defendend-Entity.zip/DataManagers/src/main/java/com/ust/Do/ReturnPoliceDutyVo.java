package com.ust.Do;

import com.ust.model.DataManager;
import lombok.Data;
@Data
public class ReturnPoliceDutyVo {
	
	public DataManager police;
	public DutyRegister duty;
	
	

}
