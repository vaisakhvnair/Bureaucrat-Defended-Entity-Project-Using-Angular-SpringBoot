package com.ust.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="InOut_tab")
public class InOut {

	@Id
	private String siNo;
	private String date;
	private String name;
	private String dept;
	private String purpose;
	private String timeIn;
	private String timeOut;
	private String dsignature;



}
