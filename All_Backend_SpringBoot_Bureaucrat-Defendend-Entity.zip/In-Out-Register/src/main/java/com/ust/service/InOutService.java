package com.ust.service;

import java.util.List;
import java.util.Optional;

import com.ust.model.InOut;

public interface InOutService {
	
	public String saveInOut(InOut f);
	public List<InOut> getAllInOut();
	public Optional<InOut> getOneInOut(String no);
	public boolean isExist(String no);
	public void deleteInOut(String no);

}
