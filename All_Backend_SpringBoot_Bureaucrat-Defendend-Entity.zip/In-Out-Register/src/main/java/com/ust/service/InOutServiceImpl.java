package com.ust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.model.InOut;
import com.ust.repo.InOutRepository;

@Service
public class InOutServiceImpl implements InOutService{
	
	@Autowired
	private InOutRepository prepo;

	@Override
	public String saveInOut(InOut p) {
		return prepo.save(p).getSiNo();
	}

	@Override
	public List<InOut> getAllInOut() {
		return prepo.findAll();
	}

	@Override
	public Optional<InOut> getOneInOut(String un) {
		return prepo.findById(un);
	}

	@Override
	public boolean isExist(String name) {
		return prepo.existsById(name); 
	}

	@Override
	public void deleteInOut(String name) {
		prepo.deleteById(name);
	}

}
