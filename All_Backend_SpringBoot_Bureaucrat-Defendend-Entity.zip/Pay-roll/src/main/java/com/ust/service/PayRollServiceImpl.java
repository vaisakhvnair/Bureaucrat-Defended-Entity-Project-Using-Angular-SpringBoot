package com.ust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.model.PayRoll;
import com.ust.repo.PayRollRepository;


@Service
public class PayRollServiceImpl implements IPayRollService{
	
	@Autowired
	private PayRollRepository prepo;

	@Override
	public String savePay(PayRoll p) {
		return prepo.save(p).getUserName();
	}

	@Override
	public List<PayRoll> getAllPay() {
		return prepo.findAll();
	}

	@Override
	public Optional<PayRoll> getOnePay(String un) {
		return prepo.findById(un);
	}

	@Override
	public boolean isExist(String name) {
		return prepo.existsById(name); 
	}

	@Override
	public void deletePay(String name) {
		prepo.deleteById(name);
	}

}
