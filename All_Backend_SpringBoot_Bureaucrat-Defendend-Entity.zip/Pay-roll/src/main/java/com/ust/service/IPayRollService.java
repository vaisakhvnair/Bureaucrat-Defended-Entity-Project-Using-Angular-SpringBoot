package com.ust.service;

import java.util.List;
import java.util.Optional;

import com.ust.model.PayRoll;

public interface IPayRollService {
	
	public String savePay(PayRoll s);
	public List<PayRoll> getAllPay();
	public Optional<PayRoll> getOnePay(String nm);
	public boolean isExist(String name);
	public void deletePay(String name);

}
