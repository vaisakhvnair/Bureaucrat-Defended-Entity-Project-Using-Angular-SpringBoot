package com.ust.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="Pay_tab")
public class PayRoll {

	@Id
	private String userName;
	private String pid;
	private String name;
	private String regularSalary;
	private String partTimeSalary;
	private String annualSalary;
	
	

}
