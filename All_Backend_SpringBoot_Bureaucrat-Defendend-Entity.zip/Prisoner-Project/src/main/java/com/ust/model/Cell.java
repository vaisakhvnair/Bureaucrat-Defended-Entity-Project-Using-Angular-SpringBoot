package com.ust.model;

import lombok.Data;

@Data
public class Cell {
	private String pid;
	private String firstName;
	private String lastName;
	private String middleName;
	private String cellNumber;

}
