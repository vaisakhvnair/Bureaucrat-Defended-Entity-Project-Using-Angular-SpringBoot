package com.ust.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


import lombok.Data;

@Entity
@Data
@Table(name = "prison_tab")
public class Prisoner {
	@Id

	private String pid;
	private String firstName;
	private String lastName;
	private String middleName;
	private String dateOfBirth;
	private String gender;
	private String age;
	private String address;
	private String dateOfArrest;
	private String caseId;
	private String crimeType;
	private String eyeWitness;
	private String witnessAddress;
	private String complaintCount;
	private String eyeColor;
	private String hairColor;
	private String faceShape;
	private String remandDate;
	private String releaseDate;
	private String courtHearing;
	private String cellNumber;
	//private String photos;
	
	


}
