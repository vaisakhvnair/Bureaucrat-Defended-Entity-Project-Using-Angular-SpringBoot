package com.ust.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.ust.model.Prisoner;

@Repository
public interface IPrisonerDao extends JpaRepository<Prisoner, String>{

}
