package com.ust.service;

import java.util.List;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.dao.IPrisonerDao;
import com.ust.model.Cell;
import com.ust.model.Prisoner;
@Service
public class PrisonerServiceImpl implements IPrisonerService {
	
	@Autowired
	IPrisonerDao ipdo;

	@Override
	public String addPrisoner(Prisoner p) {
		// TODO Auto-generated method stub
		
		return ipdo.save(p).getPid();
	}

	@Override
	public boolean isPresent(String id) {
		// TODO Auto-generated method stub
		return ipdo.existsById(id);
	}

	@Override
	public Optional<Prisoner> getDetailsById(String id) {
		// TODO Auto-generated method stub
		return ipdo.findById(id);
	}

	@Override
	public void deleteById(String id) {
		// TODO Auto-generated method stub
		ipdo.deleteById(id);
	}

	@Override
	public List<Prisoner> listAllDetails() {
		// TODO Auto-generated method stub
		return ipdo.findAll();
	}

	@Override
	public List<Cell> listAllCell() {
		Cell cell=new Cell();
		//cell.setCellNumber(ipdo.get);
		return null;
		
		
	}

	

	

}
