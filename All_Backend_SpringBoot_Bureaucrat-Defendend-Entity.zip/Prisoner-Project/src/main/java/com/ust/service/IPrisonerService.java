package com.ust.service;

import java.util.List;

import java.util.Optional;

import com.ust.model.Cell;
import com.ust.model.Prisoner;

public interface IPrisonerService {
	public String addPrisoner(Prisoner p);
	//public void updatePrisoner(Prisoner p);
	public boolean isPresent(String id);
	public Optional<Prisoner> getDetailsById(String id);
	public void deleteById(String id);
	public List<Prisoner> listAllDetails();
	public List<Cell> listAllCell();
}
