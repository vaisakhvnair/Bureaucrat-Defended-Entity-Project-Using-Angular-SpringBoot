package com.ust.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ust.model.DutyRegister;

@Repository
public interface DutyRegisterRepository extends JpaRepository<DutyRegister, String> {
	

}
