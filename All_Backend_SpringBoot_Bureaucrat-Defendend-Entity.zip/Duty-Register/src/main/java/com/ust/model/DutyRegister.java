package com.ust.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="DutyRegister_tab")
public class DutyRegister {

	@Id
	private String userName;
	private String date;
	private String timeOnDuty;
	private String name;
	private String dutyPoint;
	private String timeOffDuty;

	

}
