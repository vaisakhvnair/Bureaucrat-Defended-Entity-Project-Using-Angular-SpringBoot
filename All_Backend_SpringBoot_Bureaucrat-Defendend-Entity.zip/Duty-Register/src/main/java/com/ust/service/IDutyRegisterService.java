package com.ust.service;

import java.util.List;
import java.util.Optional;

import com.ust.model.DutyRegister;

public interface IDutyRegisterService {
	
	public String saveDataManager(DutyRegister s);
	public List<DutyRegister> getAllDataManager();
	public Optional<DutyRegister> getOneDataManager(String nm);
	public boolean isExist(String name);
	public void deleteDataManager(String name);

}
