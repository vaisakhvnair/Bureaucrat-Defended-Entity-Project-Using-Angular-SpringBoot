package com.ust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.model.DutyRegister;
import com.ust.repo.DutyRegisterRepository;

@Service
public class DutyRegisterServiceImpl implements IDutyRegisterService{
	
	@Autowired
	private DutyRegisterRepository prepo;

	@Override
	public String saveDataManager(DutyRegister p) {
		return prepo.save(p).getUserName();
	}

	@Override
	public List<DutyRegister> getAllDataManager() {
		return prepo.findAll();
	}

	@Override
	public Optional<DutyRegister> getOneDataManager(String un) {
		return prepo.findById(un);
	}

	@Override
	public boolean isExist(String name) {
		return prepo.existsById(name); 
	}

	@Override
	public void deleteDataManager(String name) {
		prepo.deleteById(name);
	}

}
