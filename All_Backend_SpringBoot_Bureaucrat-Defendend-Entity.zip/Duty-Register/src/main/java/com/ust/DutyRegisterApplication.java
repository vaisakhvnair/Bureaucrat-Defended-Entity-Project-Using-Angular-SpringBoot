package com.ust;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DutyRegisterApplication {

	public static void main(String[] args) {
		SpringApplication.run(DutyRegisterApplication.class, args);
	}

}
