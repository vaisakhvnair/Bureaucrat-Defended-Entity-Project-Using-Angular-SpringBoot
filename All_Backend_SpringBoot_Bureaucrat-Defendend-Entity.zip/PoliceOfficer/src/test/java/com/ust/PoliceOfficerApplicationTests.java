package com.ust;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.ClassOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ust.model.Police;
import com.ust.repo.PoliceRepository;

@SpringBootTest
@TestMethodOrder(org.junit.jupiter.api.MethodOrderer.OrderAnnotation.class)
class PoliceOfficerApplicationTests {

	@Autowired
	PoliceRepository pRepo;
	
	@Test
	
	void contextLoads() {
	}
	
	
	
	@Test
	@Order(1)
	public void testCreate() {
		Police p=new Police();
		p.setUserName("ROR1");
		p.setPassword("yoyo");
		p.setId("12");
		p.setName("Robin");
		p.setDesignation("Head Guard");
		p.setHiredate("2-12-1998");
		p.setEmail("robin@gmail.com");
		p.setAddress("London");
		pRepo.save(p);
		assertNotNull(pRepo.findById("ROR1").get());
		
	}
	
	@Test
	@Order(2)
	public void testReadAll() {
	List<Police> list=pRepo.findAll();	
	assertThat(list).size().isGreaterThan(0);
		
	}
	@Test
	@Order(3)
	public void testReadOne() {
	Police police=pRepo.findById("ROR1").get();
	assertEquals("London", police.getAddress());
		
	}
	@Test
	@Order(4)
	public void testUpdate() {
		
		Police p =pRepo.findById("ROR1").get();
		p.setAddress("UK");;
		pRepo.save(p);
		assertNotEquals("London", pRepo.findById("ROR1").get().getAddress());
		
	}
	@Test
	public void testDelete() {
	pRepo.deleteById("ROR1");
	assertThat(pRepo.existsById("ROR1")).isFalse();
		
	}

}





