package com.ust.Do;

import com.ust.model.Police;

import lombok.Data;
@Data
public class ReturnPoliceDutyVo {
	
	public Police police;
	public DutyRegister duty;
	
	

}
