package com.ust.Do;

import java.util.List;

import com.ust.model.Police;

import lombok.Data;
@Data
public class ReturnPoliceDutyV1 {
	
	public List<Police> pol;
	public DutyRegister[] proll;
	
	

}
