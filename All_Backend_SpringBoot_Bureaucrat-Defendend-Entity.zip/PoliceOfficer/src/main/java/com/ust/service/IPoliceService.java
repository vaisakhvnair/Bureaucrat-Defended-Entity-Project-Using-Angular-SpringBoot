package com.ust.service;

import java.util.List;
import java.util.Optional;

import com.ust.Do.ReturnPoliceDutyVo;
import com.ust.model.Police;
import com.ust.vo.ReturnPolicePayV1;
import com.ust.vo.ReturnPolicePayVo;

public interface IPoliceService {
	
	public String savePolice(Police s);
	public List<Police> getAllPolice();
	public Optional<Police> getOnePolice(String nm);
	public boolean isExist(String name);
	public void deletePolice(String name);
	public ReturnPolicePayVo getPolicePayDetails(String id);
	public List<Object>FetchAll();
	public ReturnPolicePayV1 All();
	public ReturnPoliceDutyVo getPoliceDutyDetails(String id);

}
