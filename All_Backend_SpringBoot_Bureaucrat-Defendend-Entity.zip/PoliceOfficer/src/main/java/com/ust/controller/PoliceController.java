package com.ust.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.Do.ReturnPoliceDutyVo;
import com.ust.model.Message;
import com.ust.model.Police;
import com.ust.service.PoliceServiceImpl;
import com.ust.vo.ReturnPolicePayV1;
import com.ust.vo.ReturnPolicePayVo;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/rest/police")
public class PoliceController {
	
	@Autowired
	private PoliceServiceImpl service;
	
	
	
	@PostMapping("/save") 
	public ResponseEntity<Message> saveMovie(@RequestBody Police plc) 
	{ 
		ResponseEntity<Message> resp=null; 
		try { 
			String name=service.savePolice(plc);
			resp=new ResponseEntity<Message>(new Message("SUCCESS",name+"-saved"),HttpStatus.OK); 
		} catch (Exception e) { 
			resp=new ResponseEntity<Message>(new Message("FAIL","Unable to Save"),HttpStatus.OK); 
			e.printStackTrace(); 
		} 
		return resp; 
	} 

	@GetMapping("/all")  	
	public ResponseEntity<?> getAllMovie(){
		ResponseEntity<?> resp=null; 
		try { 
			List<Police> list=service.getAllPolice(); 
			if(list!=null && !list.isEmpty()) 
				resp=new ResponseEntity<List<Police>>(list,HttpStatus.OK); 
			else 
				resp=new ResponseEntity<String>("No Data Found",HttpStatus.OK); 
		} catch (Exception e) { 
			resp=new ResponseEntity<String>("Unable to fetch Data",HttpStatus.INTERNAL_SERVER_ERROR); 
			e.printStackTrace(); 
		} 

		return resp; 
	} 


	@GetMapping("/one/{nm}")  	
	public ResponseEntity<?> getOneMovie(@PathVariable String nm) 
	{ 
		ResponseEntity<?> resp=null; 
		try { 
			Optional<Police> opt=service.getOnePolice(nm); 
			if(opt.isPresent())  
				resp=new ResponseEntity<Police>(opt.get(),HttpStatus.OK); 
			else 
				resp=new ResponseEntity<String>("No Data Found",HttpStatus.BAD_REQUEST); 
		} catch (Exception e) { 
			resp=new ResponseEntity<String>("Unable to Fetch Data",HttpStatus.INTERNAL_SERVER_ERROR); 
			e.printStackTrace(); 
		} 
		return resp; 
	} 


	@DeleteMapping("/remove/{nm}") 
	public ResponseEntity<Message> deleteMovie(@PathVariable String nm) 
	{ 
		System.out.println("welcome");
		ResponseEntity<Message> resp=null; 
		try { 
			boolean exist=service.isExist(nm); 
			if(exist) {
				service.deletePolice(nm);
				resp=new ResponseEntity<Message>(new Message("SUCCESSS",nm+"-removed"),HttpStatus.OK); 
			}else { 
				resp=new ResponseEntity<Message>(new Message("FAIL",nm+"-Not Exist"),HttpStatus.BAD_REQUEST); 
			} 
		} catch (Exception e) { 
			resp=new ResponseEntity<Message>(new Message("FAIL","Unable to Delete"),HttpStatus.INTERNAL_SERVER_ERROR); 
			e.printStackTrace(); 
		} 

		return resp; 
	} 


	@PutMapping("/update") 
	public ResponseEntity<Message> updateMovie(@RequestBody Police pls) {
		ResponseEntity<Message> resp=null; 
			try { 
				boolean exist=service.isExist(pls.getUserName()); 
				if(exist) { 
					service.savePolice(pls);
					resp=new ResponseEntity<Message>(new Message("OK",pls.getUserName()+"-Updated"),HttpStatus.OK); 
				}else { 
					resp=new ResponseEntity<Message>(new Message("OK",pls.getUserName()+"-Not Exist"),HttpStatus.BAD_REQUEST); 
				} 
			} catch (Exception e) { 
				resp=new ResponseEntity<Message>(new Message("OK","Unable to Update"),HttpStatus.INTERNAL_SERVER_ERROR); 
				e.printStackTrace(); 
			} 
			return resp; 
	} 
	@GetMapping("/red/{id}")
	public ReturnPolicePayVo getEmpDptDetails(@PathVariable String id) {
		return service.getPolicePayDetails(id);
	}
	@GetMapping("/listall")
	public List<Object> FetchAll(){

		return service.FetchAll();
	}
	@GetMapping("/listalll")
	public ReturnPolicePayV1 All1(){

		return service.All();
	}

	@GetMapping("/all111")  	
	public ResponseEntity<?> All(){
		ResponseEntity<?> resp=null; 
		try { 
			ReturnPolicePayV1 list=service.All();
			if(list!=null ) 
				resp=new ResponseEntity<ReturnPolicePayV1>(list,HttpStatus.OK); 
			else 
				resp=new ResponseEntity<String>("No Data Found",HttpStatus.OK); 
		} catch (Exception e) { 
			resp=new ResponseEntity<String>("Unable to fetch Data",HttpStatus.INTERNAL_SERVER_ERROR); 
			e.printStackTrace(); 
		} 

		return resp; 
	} 
	@GetMapping("/blue/{id}")
	public ReturnPoliceDutyVo getPolDutyDetails(@PathVariable String id) {
		return service.getPoliceDutyDetails(id);
	}
	
}
