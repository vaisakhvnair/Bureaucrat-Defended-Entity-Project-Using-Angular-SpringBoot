package com.ust.vo;

import java.util.List;

import com.ust.model.Police;

import lombok.Data;
@Data
public class ReturnPolicePayV1 {
	
	public List<Police> pol;
	public PayRoll[] proll;
	
	

}
