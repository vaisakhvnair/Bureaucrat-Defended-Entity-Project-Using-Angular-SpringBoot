package com.ust.vo;

import com.ust.model.Police;

import lombok.Data;
@Data
public class ReturnPolicePayVo {
	
	public Police police;
	public PayRoll payroll;
	
	

}
