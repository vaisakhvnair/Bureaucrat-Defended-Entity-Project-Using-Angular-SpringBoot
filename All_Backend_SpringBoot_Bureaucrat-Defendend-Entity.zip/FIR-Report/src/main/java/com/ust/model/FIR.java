package com.ust.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="FIR_tab")
public class FIR {

	@Id
	private String complaintNumber;
	private String victimName;
	private String offence;
	private String timeOfCrime;
	private String dateOfCrime;
	private String placeOfCrime;
	private String witnessStatement;
	private String culpritName;



}
