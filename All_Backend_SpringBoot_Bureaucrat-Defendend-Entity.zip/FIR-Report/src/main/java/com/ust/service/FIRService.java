package com.ust.service;

import java.util.List;
import java.util.Optional;

import com.ust.model.FIR;

public interface FIRService {
	
	public String saveFIR(FIR f);
	public List<FIR> getAllFIR();
	public Optional<FIR> getOneFIR(String no);
	public boolean isExist(String no);
	public void deleteFIR(String no);

}
