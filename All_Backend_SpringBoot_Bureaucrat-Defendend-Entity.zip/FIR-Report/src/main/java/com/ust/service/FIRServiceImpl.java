package com.ust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.model.FIR;
import com.ust.repo.FIRRepository;

@Service
public class FIRServiceImpl implements FIRService{
	
	@Autowired
	private FIRRepository prepo;

	@Override
	public String saveFIR(FIR p) {
		return prepo.save(p).getComplaintNumber();
	}

	@Override
	public List<FIR> getAllFIR() {
		return prepo.findAll();
	}

	@Override
	public Optional<FIR> getOneFIR(String un) {
		return prepo.findById(un);
	}

	@Override
	public boolean isExist(String name) {
		return prepo.existsById(name); 
	}

	@Override
	public void deleteFIR(String name) {
		prepo.deleteById(name);
	}

}
